<?php
/**
 * Default English Lexicon Entries for NutshellModx
 *
 * @package nutshellmodx
 * @subpackage lexicon
 */

$_lang['nutshellmodx'] = 'NutshellModx';
$_lang['nutshellmodx.form.error.nofields'] = 'No fields configured for NutshellModx. Please configure the FormIt parameter `nutshellFields`.';
$_lang['nutshellmodx.form.error.noemail'] = 'No contact email field configured for NutshellModx. Please add a `contact.email==formemailfieldname` to the `nutshellFields` FormIt parameter.';
